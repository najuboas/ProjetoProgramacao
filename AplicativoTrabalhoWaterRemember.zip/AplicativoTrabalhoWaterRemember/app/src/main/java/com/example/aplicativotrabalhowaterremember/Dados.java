package com.example.aplicativotrabalhowaterremember;

public class Dados {
    private  String data;
    private int qntcopos;
    private Float peso;
    private BancoDados bd;
    public Dados(String data, int qntcopos, Float peso) {
      /*  Date dataHoraAtual = new Date();
        this.data = new SimpleDateFormat("yyyy/MM/dd"). format(dataHoraAtual);*/
        this.qntcopos = qntcopos;
        this.peso = peso;
    }

    public Dados(){}

    public String getData() {
        return data;
    }

    public void setData(String data) {

        this.data = data;
    }

    public int getQntcopos() {
        return qntcopos;
    }

    public void setQntcopos(int qntcopos) {
        this.qntcopos = qntcopos;
    }

    public Float getPeso() {
        return peso;
    }

    public void setPeso(Float peso) {
        this.peso = peso;
    }

    public void salvar(){
        bd.SalvaInfo(this);
    }
}
