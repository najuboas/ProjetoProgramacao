package com.example.aplicativotrabalhowaterremember;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.Cursor;
import android.content.ContentValues;
import android.content.Context;
import android.util.Log;


import androidx.annotation.Nullable;


public class BancoDados extends SQLiteOpenHelper {

    public static final String TAG = "sql";
    public static final String NOME_BANCO = "MeuBancodeDados.db";
    public static final String TABLE_NAME = "dias";
    public static final int VERSAO_BANCO = 1;
    public static final String COLUNA0 = "dia";
    public static final String COLUNA1 = "peso";
    public static final String COLUNA2 = "qntCopos";
    public static final String SQL_CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + "(" + COLUNA0 + " DATA," + COLUNA1 + " REAL, " + COLUNA2 + " INT);";

    public BancoDados(Context context) {
        super(context, NOME_BANCO, null, VERSAO_BANCO);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            db.execSQL(SQL_CREATE_TABLE);
            Log.d(TAG, "Tabela" + TABLE_NAME + "criada com sucesso");
        } catch (Exception e) {
            Log.d(TAG, "Excessao gerada: " + e.toString());
        }


    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public String SalvaInfo(Dados dado) {

        String id = dado.getData();
        SQLiteDatabase db = getWritableDatabase();//abre a conexão com o banco de dados
        try {
            ContentValues valores = new ContentValues();
            valores.put(COLUNA0, dado.getData());
            valores.put(COLUNA1, dado.getPeso());
            valores.put(COLUNA2, dado.getQntcopos());
            Cursor c = db.query(TABLE_NAME, null, "dia=?", new String[]{dado.getData()}, null, null, null, null);
            if (c.moveToFirst()) {//se existir uma primeira posição na pesquisa
                int count = db.update(TABLE_NAME, valores, "data=?", new String[]{String.valueOf(dado.getData())});
                return "atualizado";

            } else {
                long d = db.insert(TABLE_NAME, null, valores);
                return "criado";

            }
        } finally {
            db.close();//fecha a conexão
        }
    }

    public Dados PegaInfo(Dados dado) {
        SQLiteDatabase db = getWritableDatabase();
        Dados saida = new Dados();

        try {
            Cursor c = db.query(TABLE_NAME, null, "data=?", new String[]{dado.getData()}, null, null, null, null);
            if (c.moveToFirst()) {
                saida.setData(String.valueOf(c.getInt(c.getColumnIndexOrThrow("data"))));
                saida.setPeso(Float.valueOf(c.getString(c.getColumnIndexOrThrow("peso"))));
                saida.setQntcopos(Integer.parseInt(c.getString(c.getColumnIndexOrThrow("qntcopos"))));
                return saida;
            }
            else {
                saida.setData(null);
                saida.setPeso(null);
                saida.setQntcopos(0);
                return saida;
            }
        } finally {
            db.close();
        }
    }

}

